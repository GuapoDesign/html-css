import Link from 'next/link';
import { ArrowLeft, ArrowRight, Package, ShoppingBag } from 'lucide-react';

const items = [
  ['PLAYER KEY','R$ 20,00','Entrada vitalícia para jogadores.'],
  ['MESTRE KEY','R$ 55,00','Ferramentas para criar e conduzir mesas.'],
  ['PARTY PACK / 4','R$ 121,50','4 jogadores + 1 mestre.'],
  ['PARTY PACK / 6','R$ 148,75','6 jogadores + 1 mestre.'],
  ['PARTY PACK / 12','R$ 236,00','12 jogadores + 1 mestre.'],
];

export default function StorePage() {
  return (
    <main className="store-page">
      <header className="store-head">
        <Link href="/" className="back"><ArrowLeft size={16}/> Voltar</Link>
        <div className="brand"><span>NEXUS</span><b>TABLETOP</b></div>
        <ShoppingBag size={19}/>
      </header>
      <section className="store-page-hero">
        <div className="eyebrow">LOJA / ACESSOS</div>
        <h1>ESCOLHA<br/><em>SEU ACESSO.</em></h1>
        <p>Uma página de catálogo independente, pronta para receber checkout e autenticação depois.</p>
      </section>
      <section className="catalog">{items.map(([name, price, desc]) => <article className="catalog-card" key={name}><div className="catalog-icon"><Package size={20}/></div><small>LICENÇA DIGITAL</small><h2>{name}</h2><p>{desc}</p><strong>{price}</strong><button>ADICIONAR <ArrowRight size={16}/></button></article>)}</section>
      <footer className="store-footer"><span>INTERFACE CONCEITUAL</span><span>2026</span></footer>
    </main>
  );
}
