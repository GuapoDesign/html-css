# Nexus Tabletop — clone conceitual em Next.js

Esta é uma implementação independente inspirada na estrutura/linguagem de um site de VTT 3D. Não usa identidade, textos, imagens ou código proprietário do Nexus original.

## Rodar localmente

```bash
npm install
npm run dev
```

Abra `http://localhost:3000`.

## O que já funciona

- Landing page responsiva
- Navegação por âncoras
- Menu mobile
- Mockup visual de cena 3D sem assets externos
- Cards de recursos
- Cards de produtos
- Carrinho visual (estado local)
- FAQ expansível
- Layout responsivo
- Estrutura App Router do Next.js

## Próxima etapa sugerida

Conectar o carrinho a uma página `/checkout`, persistir estado, adicionar `/login`, `/account` e `/admin`, e depois transformar o mockup de cena em um módulo de tabletop real.
