'use client';

import { useState } from 'react';
import { ArrowRight, ChevronDown, CirclePlay, CloudRain, Gamepad2, Menu, Moon, Move3d, Package, Shield, ShoppingBag, Sparkles, Sun, X, Zap } from 'lucide-react';

const products = [
  { id: 'player', title: 'PLAYER KEY', desc: 'Acesso vitalício para entrar em mesas e controlar personagens.', price: 'R$ 20,00', tag: 'ENTRADA' },
  { id: 'master', title: 'MESTRE KEY', desc: 'Editor, mapas, câmera, clima, tokens e hospedagem de mesas.', price: 'R$ 55,00', tag: 'POPULAR' },
  { id: 'party4', title: 'PARTY PACK / 4', desc: '4 acessos de jogadores + 1 acesso de mestre.', price: 'R$ 121,50', old: 'R$ 135,00', tag: '-10%' },
  { id: 'party6', title: 'PARTY PACK / 6', desc: '6 acessos de jogadores + 1 acesso de mestre.', price: 'R$ 148,75', old: 'R$ 175,00', tag: '-15%' },
  { id: 'party12', title: 'PARTY PACK / 12', desc: '12 acessos de jogadores + 1 acesso de mestre.', price: 'R$ 236,00', old: 'R$ 295,00', tag: 'MELHOR VALOR' },
];

const features = [
  { icon: CloudRain, kicker: 'TEMPO REAL', title: 'Clima & Luz', text: 'Dia e noite, neblina, chuva e neve com presets e controles em tempo real.' },
  { icon: Move3d, kicker: 'IMERSÃO', title: 'Câmera Dinâmica', text: 'Zoom, tilt, profundidade e movimentos suaves para criar cenas cinematográficas.' },
  { icon: Package, kicker: 'CONSTRUÇÃO', title: 'Editor de Mapas', text: 'Monte arenas e cenários com componentes, objetos, terrenos e assets.' },
  { icon: Gamepad2, kicker: 'CONTROLE', title: 'Tokens Dinâmicos', text: 'Personagens com estados visuais, animações e movimentação fluida.' },
  { icon: Zap, kicker: 'SANDBOX', title: 'Objetos Interativos', text: 'Esconda objetos, mova elementos da cena e altere a iluminação.' },
  { icon: Shield, kicker: 'ONLINE', title: 'Multiplayer', text: 'Conecte o grupo em uma sala e sincronize as ações da sessão.' },
];

const faqs = [
  ['O que é o Nexus?', 'Um tabletop virtual com foco em cenas 3D, ambientação e apresentação cinematográfica para RPG de mesa.'],
  ['Precisa de assinatura?', 'Não. A proposta da interface é apresentar licenças de compra única; uma assinatura opcional pode existir como apoio.'],
  ['Funciona no celular?', 'Nesta versão conceitual, a experiência é responsiva. O tabletop 3D em si poderia ter um cliente separado por plataforma.'],
  ['Posso usar qualquer sistema?', 'Sim. O posicionamento é agnóstico: você pode adaptar regras e fichas ao sistema que estiver jogando.'],
];

function Noise() { return <div className="noise" aria-hidden="true" />; }

export function Site() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeFaq, setActiveFaq] = useState(0);
  const [cart, setCart] = useState<string[]>([]);

  const addToCart = (id: string) => setCart((items) => items.includes(id) ? items : [...items, id]);

  return (
    <main>
      <Noise />
      <header className="topbar">
        <a className="brand" href="#top" aria-label="Nexus home"><span>NEXUS</span><b>TABLETOP</b></a>
        <nav className="desktop-nav">
          <a href="#explore">EXPLORAR</a><a href="#features">RECURSOS</a><a href="#pricing">ACESSO</a><a href="#faq">FAQ</a>
        </nav>
        <div className="header-actions">
          <button className="icon-button" aria-label="Carrinho" onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}><ShoppingBag size={18}/><span>{cart.length}</span></button>
          <a className="header-cta" href="#pricing">ENTRAR NA MESA <ArrowRight size={16}/></a>
          <button className="mobile-menu" aria-label="Abrir menu" onClick={() => setMenuOpen((v) => !v)}>{menuOpen ? <X/> : <Menu/>}</button>
        </div>
      </header>

      {menuOpen && <div className="mobile-nav"><a href="#explore" onClick={() => setMenuOpen(false)}>EXPLORAR</a><a href="#features" onClick={() => setMenuOpen(false)}>RECURSOS</a><a href="#pricing" onClick={() => setMenuOpen(false)}>ACESSO</a><a href="#faq" onClick={() => setMenuOpen(false)}>FAQ</a></div>}

      <section id="top" className="hero section-grid">
        <div className="hero-copy">
          <div className="eyebrow"><span className="pulse"/> VTT 3D / EXPERIÊNCIA CINEMATOGRÁFICA</div>
          <h1>SEU RPG.<br/><em>OUTRA DIMENSÃO.</em></h1>
          <p>Uma interface de tabletop inspirada em ambientes imersivos: mapas, luz, clima e presença de cena em um único espaço.</p>
          <div className="hero-buttons"><a className="primary-btn" href="#pricing">COMEÇAR AGORA <ArrowRight size={18}/></a><a className="ghost-btn" href="#explore"><CirclePlay size={18}/> VER EXPERIÊNCIA</a></div>
          <div className="hero-meta"><div><b>01</b><span>AMBIENTAÇÃO</span></div><div><b>02</b><span>CONTROLE</span></div><div><b>03</b><span>CONEXÃO</span></div></div>
        </div>
        <div className="hero-scene" aria-label="Mockup 3D do tabletop">
          <div className="scene-sky"><Sun className="sun" size={46}/></div>
          <div className="scene-moon"><Moon size={28}/></div>
          <div className="mountain m1"/><div className="mountain m2"/><div className="mountain m3"/>
          <div className="fog f1"/><div className="fog f2"/>
          <div className="scene-ui"><span>CAMPAIGN 01</span><span>01:48:22</span></div>
          <div className="scene-token token-a">A</div><div className="scene-token token-b">R</div><div className="scene-token token-c">M</div>
          <div className="scene-floor"/>
          <div className="scene-caption"><small>LIVE SESSION</small><strong>THE FORGOTTEN PASS</strong></div>
        </div>
      </section>

      <section id="explore" className="ticker"><div>CLIMA <span>✦</span> LUZ <span>✦</span> MAPAS <span>✦</span> TOKENS <span>✦</span> MULTIPLAYER <span>✦</span> CÂMERA <span>✦</span> CLIMA <span>✦</span> LUZ <span>✦</span> MAPAS <span>✦</span> TOKENS <span>✦</span></div></section>

      <section id="features" className="feature-section section-grid">
        <div className="section-intro"><div className="eyebrow">01 / EXPLORE O SISTEMA</div><h2>FEITO PARA<br/><em>FAZER CENA.</em></h2><p>O visual não substitui o RPG. Ele potencializa cada momento em que a mesa precisa sentir o que está acontecendo.</p></div>
        <div className="feature-grid">{features.map(({ icon: Icon, kicker, title, text }) => <article className="feature-card" key={title}><div className="feature-icon"><Icon size={19}/></div><div className="mini-label">{kicker}</div><h3>{title}</h3><p>{text}</p><span className="card-line"/></article>)}</div>
      </section>

      <section className="statement"><div className="statement-bg"/><div className="statement-content"><Sparkles size={18}/><div className="eyebrow">A MESA VIRA CENA</div><h2>VOCÊ NARRA.<br/><em>A INTERFACE RESPONDE.</em></h2><p>Atmosfera, informação e interação sem roubar o protagonismo dos jogadores.</p></div></section>

      <section id="pricing" className="store section-grid"><div className="section-intro store-intro"><div className="eyebrow">02 / ESCOLHA SEU ACESSO</div><h2>ENTRE NA<br/><em>MESA.</em></h2><p>Uma estrutura comercial inspirada em compra única e expansão por pacotes.</p></div>
        <div className="products">{products.map((p) => <article className={`product ${p.id === 'master' ? 'featured' : ''}`} key={p.id}><div className="product-top"><span>{p.tag}</span><Package size={19}/></div><h3>{p.title}</h3><p>{p.desc}</p><div className="price">{p.old && <del>{p.old}</del>}<strong>{p.price}</strong></div><button className="product-btn" onClick={() => addToCart(p.id)}>{cart.includes(p.id) ? 'ADICIONADO ✓' : 'ADICIONAR'} <ArrowRight size={16}/></button></article>)}</div>
      </section>

      <section id="faq" className="faq section-grid"><div className="section-intro"><div className="eyebrow">03 / PERGUNTAS FREQUENTES</div><h2>RESPOSTAS<br/><em>DIRETAS.</em></h2></div><div className="faq-list">{faqs.map(([q, a], i) => <button className={`faq-item ${activeFaq === i ? 'open' : ''}`} key={q} onClick={() => setActiveFaq(activeFaq === i ? -1 : i)}><div><span>0{i + 1}</span><h3>{q}</h3></div><ChevronDown size={18}/>{activeFaq === i && <p>{a}</p>}</button>)}</div></section>

      <footer><div className="footer-brand"><span>NEXUS</span><b>TABLETOP</b><p>Uma interface própria para experiências de RPG mais cinematográficas.</p></div><div className="footer-links"><div><small>NAVIGAÇÃO</small><a href="#explore">Explorar</a><a href="#features">Recursos</a><a href="#pricing">Acesso</a></div><div><small>PROJETO</small><a href="#faq">FAQ</a><a href="#top">Topo</a></div></div><div className="footer-bottom"><span>INTERFACE CONCEITUAL / 2026</span><span>COPY NÃO INCLUÍDO — DESIGN INSPIRADO, NÃO OFICIAL</span></div></footer>
    </main>
  );
}
